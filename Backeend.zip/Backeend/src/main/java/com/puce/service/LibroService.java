package com.puce.service;

import com.puce.entity.Libro;
import com.puce.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service

public class LibroService {
    /*Inyección de dependencias*/

    @Autowired
    private LibroRepository libroRepository;


    //Guardar
    public Libro guardarLibro(Libro libro){
        libroRepository.save(libro);
        return  libro;
    }
}
